<?php include 'config.php';
$select = "SELECT * FROM categories";
$run = mysqli_query($config, $select);

$select2 = "SELECT * FROM blog ORDER BY publish_date DESC LIMIT 5";
$run2 = mysqli_query($config, $select2);
?>
<div class="col-lg-4">
    <div class="card">
        <div class="card-body d-flex right-section">
            <div id="categories">
                <h6>Categories</h6>
                <ul>
                    <?php while ($cats=mysqli_fetch_assoc($run)){?>
                    <li><a href="category.php?id=<?= $cats['cat_id'] ?>" class="fw-bold text-success"><?= $cats['cat_name'] ?></a></li>
                    <?php }?>
                </ul>
            </div>
            <div id="posts">
                <h6>Recent Posts</h6>
                <ul>
                    <?php while ($posts=mysqli_fetch_assoc($run2)){?>
                    <li><a href="postPage.php?id=<?= $posts['blog_id'] ?>" class="fw-bold text-success"><?= $posts['blog_title'] ?></a></li>
                    <?php }?>
                </ul>
            </div>
        </div>
    </div>
</div>