<?php
session_start();
ob_start();
$page = basename($_SERVER['PHP_SELF'], ".php");
include 'config.php';
$select = "SELECT * FROM categories";
$run = mysqli_query($config, $select);
//For Security
if (!isset($_SESSION['user_data'])) {
    header("location:http://localhost/blog/userLogin.php");
}
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> -->
    <link rel="stylesheet" href="./style/style.css">
    <link rel="stylesheet" href="./style/navBarStyle.css">
    <link rel="stylesheet" href="./style/about.css">
    <link rel="stylesheet" href="./style/blog.css">
    <link rel="stylesheet" href="./style/postComment.css">
    <!-- <link rel="stylesheet" href="contact.css"> -->
</head>

<body class="bg-light">
    <nav class="navbar navbar-expand-lg border-bottom p-3 fixed-top" style="background-color: #192e43" data-bs-theme="dark">
        <div class="container">
            <a class="navbar-brand" href="index.php"><b>BLOG</b></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarColor02">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link <?= ($page == "index") ? "active" : ""; ?>" href="index.php">Home
                            <span class="visually-hidden">(current)</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#blog">Blogs
                            <span class="visually-hidden">(current)</span>
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Categories</a>
                        <div class="dropdown-menu" style="background-color: #192e43">
                            <?php while ($cats = mysqli_fetch_assoc($run)) { ?>
                                <a class="dropdown-item" href="category.php?id=<?= $cats['cat_id'] ?>"><?= $cats['cat_name'] ?></a>
                            <?php } ?>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#aboutus">About
                            <span class="visually-hidden">(current)</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contact">Contact
                            <span class="visually-hidden">(current)</span>
                        </a>
                    </li>
                </ul>
                <?php
                if (isset($_GET['keyword'])) {
                    $keyword = $_GET['keyword'];
                } else {
                    $keyword = "";
                }
                ?>

                <form class="d-flex" action="search.php" method="GET">
                    <div class="input-group rounded">
                        <input type="search" name="keyword" class="form-control" placeholder="Search" aria-label="Search" aria-describedby="search-addon" value="<?= $keyword ?>" />
                        <span class="input-group-text border-0" id="search-addon">
                            <i class="fas fa-search"></i>
                        </span>
                    </div>
                    <!-- <input class="form-control me-sm-2" type="search" name="keyword" maxlength="70" placeholder="Search" autocomplete="off" value="<?= $keyword ?>" required> -->
                    <!-- <button class="btn btn-secondary my-2 my-sm-0" type="submit">Search</button> -->
                </form> &nbsp; &nbsp;
                <!-- <div class="dropdown text-end">
                    <a href="#" class="d-block link-body-emphasis text-decoration-none dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                    <img src="loginIMG.png" alt="mdo" width="32" height="32" class="rounded-circle">
                    </a>
                    <ul class="dropdown-menu text-small">
                    <li><a class="dropdown-item" href="login.php">Login</a></li>
                    </ul>
                </div> -->
                <ul class="nav navbar-nav navbar-right">
                    <a class="text-decoration-none text-white" href="logout.php"><i class="fa-solid fa-arrow-right-from-bracket"></i></a>
                </ul>
            </div>
        </div>
    </nav>