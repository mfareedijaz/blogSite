<?php
$config = mysqli_connect("localhost", "root", "", "blog_web") or die("Database not connected");
?>