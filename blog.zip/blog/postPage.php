<?php include 'header.php';
include 'config.php';
$id = $_GET['id'];
if (empty($id)) {
    header("location:index.php");
}
$sql = "SELECT * FROM blog WHERE blog_id = $id";
$run = mysqli_query($config, $sql);
$post = mysqli_fetch_assoc($run);

if (isset($_SESSION['user_data'])) {
    $userid = $_SESSION['user_data']['0'];
    $userName = $_SESSION['user_data']['1'];
    $userEmail = $_SESSION['user_data']['2'];
}
?>
<div class="container pt-5 mt-5 mb-4">
    <div class="row">
        <div class="col-lg-8">
            <div class="card shadow p-3">
                <div class="class-body">
                    <div id="single_img">
                        <a href="admin/upload/<?= $post['blog_image'] ?>">
                            <img src="admin/upload/<?= $post['blog_image'] ?>" alt="">
                        </a>
                    </div>
                    <hr>
                    <div>
                        <h3><?= ucfirst($post['blog_title']) ?></h3>
                        <p><?= $post['blog_body'] ?></p>
                    </div>
                </div>
            </div>
        </div>
        <?php include 'sideBar.php' ?>
    </div>
</div>
<?php
// make sure you have a post ID 1 in your "posts table"
$post_id = $id;
?>
<div class="container">
    <form action="#" method="post">

        <input type="hidden" name="post_id" value="<?php echo $post_id; ?>" required>

        <div class="form-group">
            <label for="name">Your name</label>
            <input type="text" class="form-control" name="name" required>
        </div>

        <div class="form-group">
            <label for="email">Your email address</label>
            <input type="email" class="form-control" name="email" required>
        </div>

        <div class="form-group">
            <label for="comment">Comment</label>
            <textarea class="form-control" name="comment" rows="4" required></textarea>
        </div>

        <div class="form-group mt-2">
            <input type="submit" class="btn btn-primary" value="Add Comment" name="post_comment">
        </div>
    </form>
</div>
<?php

if (isset($_POST["post_comment"])) {
    $name = mysqli_real_escape_string($config, $_POST["name"]);
    $email = mysqli_real_escape_string($config, $_POST["email"]);
    $comment = mysqli_real_escape_string($config, $_POST["comment"]);
    $post_id = mysqli_real_escape_string($config, $_POST["post_id"]);
    $reply_of = 0;

    mysqli_query($config, "INSERT INTO postcomments(name, email, comment, post_id, created_at, reply_of) VALUES ('" . $name . "', '" . $email . "', '" . $comment . "', '" . $post_id . "', NOW(), '" . $reply_of . "')");
    echo '<script>alert("Comment has been posted.")</script>';
}



// get all comments of post
$result = mysqli_query($config, "SELECT * FROM postcomments WHERE post_id = " . $post_id);

// save all records from database in an array
$comments = array();
while ($row = mysqli_fetch_object($result)) {
    array_push($comments, $row);
}

// loop through each comment
foreach ($comments as $comment_key => $comment) {
    // initialize replies array for each comment
    $replies = array();

    // check if it is a comment to post, not a reply to comment
    if ($comment->reply_of == 0) {
        // loop through all comments again
        foreach ($comments as $reply_key => $reply) {
            // check if comment is a reply
            if ($reply->reply_of == $comment->id) {
                // add in replies array
                array_push($replies, $reply);

                // remove from comments array
                unset($comments[$reply_key]);
            }
        }
    }

    // assign replies to comments object
    $comment->replies = $replies;
}
?>

<ul class="list-group container mt-3">
    <?php foreach ($comments as $comment) : ?>
        <li class="list-group-item border comment-card">
            <div class="font-weight-bold"><?php echo $comment->name; ?></div>

            <p class="mb-1"><?php echo $comment->comment; ?></p>

            <small class="text-muted"><?php echo date("F d, Y h:i a", strtotime($comment->created_at)); ?></small>

            <div class="text-primary reply-link" data-id="<?php echo $comment->id; ?>" onclick="showReplyForm(this);">Reply</div>

            <form action="#" method="post" id="form-<?php echo $comment->id; ?>" class="mt-2 reply-form" style="display: none;">
                <input type="hidden" name="reply_of" value="<?php echo $comment->id; ?>" required>
                <input type="hidden" name="post_id" value="<?php echo $post_id; ?>" required>

                <div class="form-group">
                    <label for="name">Your name</label>
                    <input type="text" class="form-control" name="name" required>
                </div>

                <div class="form-group">
                    <label for="email">Your email address</label>
                    <input type="email" class="form-control" name="email" required>
                </div>

                <div class="form-group">
                    <label for="comment">Comment</label>
                    <textarea class="form-control" name="comment" required></textarea>
                </div>

                <div class="form-group mt-3">
                    <input type="submit" class="btn btn-primary" value="Reply" name="do_reply">
                </div>
            </form>
            <ul class="comments reply list-unstyled">
                <?php foreach ($comment->replies as $reply) : ?>
                    <li class="media mt-2">
                        <div class="media-body">
                            <h5 class="mt-0 mb-1"><strong><?php echo $reply->name; ?></strong></h5>
                            <p><?php echo $reply->comment; ?></p>
                            <small class="text-muted"><?php echo date("F d, Y h:i a", strtotime($reply->created_at)); ?></small>
                        </div>

                        <div class="media-footer" onclick="showReplyForReplyForm(this);" data-name="<?php echo $reply->name; ?>" data-id="<?php echo $comment->id; ?>">
                            <button class="btn btn-sm btn-outline-primary">Reply</button>
                        </div>
                    </li> <hr>
                <?php endforeach; ?>
            </ul>



        </li>
    <?php endforeach; ?>
</ul>

<?php
if (isset($_POST["do_reply"])) {
    $name = mysqli_real_escape_string($config, $_POST["name"]);
    $email = mysqli_real_escape_string($config, $_POST["email"]);
    $comment = mysqli_real_escape_string($config, $_POST["comment"]);
    $post_id = mysqli_real_escape_string($config, $_POST["post_id"]);
    $reply_of = mysqli_real_escape_string($config, $_POST["reply_of"]);

    // $result = mysqli_query($config, "SELECT * FROM postcomments WHERE id = " . $reply_of);
    // if (mysqli_num_rows($result) > 0) {
    //     $row = mysqli_fetch_object($result);

        // sending email
        // $headers = 'From: YourWebsite <no-reply@yourwebsite.com>' . "\r\n";
        // $headers .= 'MIME-Version: 1.0' . "\r\n";
        // $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

        // $subject = "Reply on your comment";

        // $body = "<h1>Reply from:</h1>";
        // $body .= "<p>Name: " . $name . "</p>";
        // $body .= "<p>Email: " . $email . "</p>";
        // $body .= "<p>Reply: " . $comment . "</p>";

        // mail($row->email, $subject, $body, $headers);
    // }

    mysqli_query($config, "INSERT INTO postcomments(name, email, comment, post_id, created_at, reply_of) VALUES ('" . $name . "', '" . $email . "', '" . $comment . "', '" . $post_id . "', NOW(), '" . $reply_of . "')");
    echo '<script>alert("Reply has been posted.")</script>';
}

?>

<?php include 'footer.php'; ?>