<?php include 'header.php' ;
if (isset($_POST['add_user'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = sha1($_POST['password']);
    $c_password = sha1($_POST['confirm_password']);
    $role = $_POST['role'];

    if (strlen($username) < 6 || strlen($username) > 20) {
        $error = "Username must be between 6 to 20 characters";
    }
    elseif (strlen($password) <= 8) {
        $error = "Password must be 8 characters long";
    }
    elseif ($password != $c_password) {
        $error = "Confirm password must be same as password";
    }
    else {
        $sql = "SELECT * FROM user WHERE email = '$email'";
        $query = mysqli_query($config, $sql);
        $row = mysqli_num_rows($query);
        if ($row >= 1) {
            $error = "Email already exists";
        }
        else {
            $sql2 = "INSERT INTO user (username,email,password,role) VALUES('$username', '$email', '$password', '$role')";
            $query2 = mysqli_query($config, $sql2);
           if ($query2) {
                $msg = ['User has been added successfully','alert-success'];
                $_SESSION['msg'] = $msg;
                header("location:users.php");
           }
        }
    }
}
?>
<div class="container">
    <div class="row">
        <div class="col-md-5 m-auto p-3">
            <form action="" method="POST">
                <?php
                    if (!empty($error)) {
                        echo "<p class='bg-danger text-white p-2'>".$error."</p>";
                    }
                ?>
                <h4>Create new user!</h4>
                <div class="form-floating mb-3">
                    <input type="text" name="username" class="form-control" id="floatingEmail" placeholder="namexyz" value="<?=(!empty($error))?$username:'' ?>" required>
                    <label for="floatingEmail">Username</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="email" name="email" class="form-control" id="floatingEmail" placeholder="name@example.com" value="<?=(!empty($error))? $email:'' ?>" required>
                    <label for="floatingEmail">Email address</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="password" class="form-control" name="password" id="floatingPassword" placeholder="Password" required>
                    <label for="floatingPassword">Password</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="password" name="confirm_password" class="form-control" id="floatingPassword" placeholder="Confirm Password" required>
                    <label for="floatingPassword">Confirm Password</label>
                </div>
                <div class="form-floating mb-3">
                    <select name="role" class="form-select" id="floatingSelect" aria-label="Floating label select example" required>
                        <option value="1">Admin</option>
                        <option value="0">Co-Admin</option>
                    </select>
                    <label for="floatingSelect">Select Role</label>
                </div>
                <div>
                    <input type="submit" name="add_user" value="Create" class="btn btn-dark w-100">
                </div>
            </form>
        </div>
    </div>
</div>
<?php include 'footer.php' ?>