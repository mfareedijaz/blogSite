<?php include 'header.php';
include 'config.php';


if (!isset($_GET['page'])) {
	$page = 1;
} else {
	$page = $_GET['page'];
}

$limit = 3;
$offset = ($page - 1) * $limit;

$sql = "SELECT * FROM blog LEFT JOIN categories ON blog.category = categories.cat_id LEFT JOIN
 user ON blog.author_id = user.user_id ORDER BY blog.publish_date DESC LIMIT $offset,$limit";

$run = mysqli_query($config, $sql);
$row = mysqli_num_rows($run);

if (isset($_SESSION['user_data'])) {
	$userid = $_SESSION['user_data']['0'];
	$userName = $_SESSION['user_data']['1'];
	$userEmail = $_SESSION['user_data']['2'];
}
?>
<div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
	<div class="carousel-inner">
		<div class="carousel-item active">
			<img src="./carousel/3.jpg" class="d-block w-100" alt="Slide 1" style="max-height: 600px; object-fit: cover;">
		</div>
		<div class="carousel-item">
			<img src="./carousel/1.jpg" class="d-block w-100" alt="Slide 2" style="max-height: 600px; object-fit: cover;">
		</div>
		<div class="carousel-item">
			<img src="./carousel/2.jpg" class="d-block w-100" alt="Slide 3" style="max-height: 600px; object-fit: cover;">
		</div>
	</div>
</div>

<div id="blog" class="container mt-5">
	<h1><b>BLOGS</b></h1>
	<div class="line mb-4"></div>
	<div class="row">
		<div class="col-lg-8">
			<?php
			if ($row) {
				while ($result = mysqli_fetch_assoc($run)) {
			?>
					<div class="card shadow mb-3">
						<div class="card-body d-flex blog_flex">
							<div class="flex-part1">
								<a href="postPage.php?id=<?= $result['blog_id'] ?>"> <img src="admin/upload/<?= $result['blog_image'] ?>"> </a>
							</div>
							<div class="flex-grow-1 flex-part2">
								<a href="postPage.php?id=<?= $result['blog_id'] ?>" id="title"><?= ucfirst($result['blog_title']) ?></a>
								<p>
									<a href="postPage.php?id=<?= $result['blog_id'] ?>" id="body">
										<?= strip_tags(substr($result['blog_body'], 0, 200)) . "..." ?>
									</a> <span><br>
										<a href="postPage.php?id=<?= $result['blog_id'] ?>" class="btn btn-sm btn-outline-dark">Continue Reading
										</a></span>
								</p>
								<ul>
									<li class="me-2"><a href="" class="text-info"> <span>
												<i class="fa fa-pencil-square-o" aria-hidden="true"></i></span><?= $result['username'] ?></a>
									</li>
									<li class="me-2">
										<a href="" class="text-info"> <span><i class="fa fa-calendar-o" aria-hidden="true"></i></span> <?= date('d-M-Y', strtotime($result['publish_date'])) ?> </a>
									</li>
									<li>
										<a href="category.php?id=<?= $result['cat_id'] ?>" class="text-danger"> <span><i class="fa fa-tag" aria-hidden="true"></i></span> <?= $result['cat_name'] ?> </a>
									</li>
								</ul>
							</div>
						</div>
					</div>
			<?php }
			} ?>
			<?php
			$pagination = "SELECT * FROM blog";
			$run_q = mysqli_query($config, $pagination);
			$totalPosts = mysqli_num_rows($run_q);
			$pages = ceil($totalPosts / $limit);
			if ($totalPosts > $limit) {
			?>
				<ul class="pagination pt-2 pb-5">
					<?php for ($i = 1; $i <= $pages; $i++) { ?>
						<li class="page-item <?= ($i == $page) ? $active = "active" : "" ?>">
							<a href="index.php?page=<?= $i ?>" class="page-link"><?= $i ?></a>
						</li>
					<?php } ?>
				</ul>
			<?php } ?>
		</div>
		<?php include 'sideBar.php' ?>
	</div>
</div>
<hr class="container">
<section class="about-us-section" id="aboutus">
	<div class="container">
		<div class="row gx-4 align-items-center justify-content-between">
			<div class="col-md-5 order-2 order-md-1">
				<div class="about-us-content">
					<h2 class="display-4">About Us</h2>
					<p class="lead">Explore a tapestry of thoughts as our diverse team of writers and creators share their passions, expertise, and unique perspectives on our dynamic blogging platform.</p>
					<p class="lead"><i>"Where words breathe life, our blog is the heartbeat of expression."</i></p>
				</div>
			</div>
			<div class="col-md-6 offset-md-1 order-1 order-md-2">
				<div id="imageCarousel" class="carousel slide" data-ride="carousel">
					<div class="carousel-inner">
						<div class="carousel-item active">
						<img class="img-fluid aboutimg" src="./carousel/about1.jpg" alt="Slide 1">
						</div>
						<div class="carousel-item">
							<img class="img-fluid aboutimg" src="./carousel/about3.jpg" alt="Slide 2">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<hr class="container">
<div class="content mt-5" id="contact">
	<h1 style="font-size: 1.4rem; text-align: center; font-family: 'Nanum Gothic', sans-serif;"><b>CONTACT US</b></h1>
	<div class="line mb-5"></div>
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-md-10 mb-5">

				<div class="row justify-content-center">
					<div class="col-md-6">

						<h3 class="heading mb-4">Let's talk about everything!</h3>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptas debitis, fugit natus?</p>

						<p><img src="images/undraw-contact.svg" alt="Image" class="img-fluid"></p>

					</div>
					<div class="col-md-6">

						<form class="contact-form" method="post" id="contactForm" name="contactForm" onsubmit="return validateForm()">
							<div class="row mt-2">
								<div class="col-md-12 form-group">
									<input type="text" class="form-control" name="name" id="name" placeholder="Your name" value="<?= $userName ?>" required>
									<div class="text-danger"><?php if (isset($error_name)) echo $error_name; ?></div>
								</div>
							</div>
							<div class="row mt-2">
								<div class="col-md-12 form-group">
									<input type="email" class="form-control" name="email" id="email" placeholder="Email" value="<?= $userEmail ?>" required>
									<div class="text-danger"><?php if (isset($error_email)) echo $error_email; ?></div>
								</div>
							</div>
							<div class="row mt-2">
								<div class="col-md-12 form-group">
									<input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
									<div class="text-danger"><?php if (isset($error_subject)) echo $error_subject; ?></div>
								</div>
							</div>
							<div class="row mt-2">
								<div class="col-md-12 form-group">
									<textarea class="form-control" name="message" id="message" cols="30" rows="7" placeholder="Write your message" required></textarea>
									<div class="text-danger"><?php if (isset($error_subject)) echo $error_subject; ?></div>
								</div>
							</div>
							<div class="row mt-2">
								<div class="col-12">
									<input type="submit" value="Send Message" name="submit" class="btn btn-primary rounded-0 py-2 px-4">
									<span class="submitting"></span>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
include 'footer.php';
if (isset($_POST['submit'])) {
	$readerid = $userid;
	$readername = $_POST['name'];
	$readeremail = $_POST['email'];
	$message = $_POST['message'];
	$subject = $_POST['subject'];

	$sql1 = "INSERT INTO comment (reader_id, name, email, message, subject) VALUES ('$readerid', '$readername', '$readeremail', '$message', '$subject')";
	$query1 = mysqli_query($config, $sql1);
	if ($query1) {
		echo '<script>alert("Message sent successfully.");</script>';
	} else {
		echo '<script>alert("Message not sent.");</script>';
	}
}
?>