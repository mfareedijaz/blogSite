<?php
session_start();
include 'config.php';
ob_start();
if (isset($_SESSION['user_data'])) {
    header("location:http://localhost/blog/index.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link rel="stylesheet" href="./style/userLogin.css">
</head>

<body>
    <div class="section">
        <div class="container">
            <div class="row full-height justify-content-center">
                <div class="col-12 text-center align-self-center py-5">
                    <div class="section pb-5 pt-5 pt-sm-2 text-center">
                        <h6 class="mb-0 pb-3"><span>Log In </span><span>Sign Up</span></h6>
                        <input class="checkbox" type="checkbox" id="reg-log" name="reg-log" />
                        <label for="reg-log"></label>
                        <div class="card-3d-wrap mx-auto">
                            <div class="card-3d-wrapper">
                                <div class="card-front">
                                    <div class="center-wrap">
                                        <div class="section text-center">
                                            <form action="" method="post">
                                                <h4 class="mb-4 pb-3">Log In</h4>
                                                <div class="form-group">
                                                    <input type="email" name="reader_email" class="form-style" placeholder="Your Email" id="logemail" autocomplete="off">
                                                    <i class="input-icon uil uil-at"></i>
                                                </div>
                                                <div class="form-group mt-2">
                                                    <input type="password" name="reader_pass" class="form-style" placeholder="Your Password" id="logpass" autocomplete="off">
                                                    <i class="input-icon uil uil-lock-alt"></i>
                                                </div>
                                                <div>
                                                    <input type="submit" name="login" class="btn mt-4">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-back">
                                    <div class="center-wrap">
                                        <div class="section text-center">
                                            <form action="" method="post">
                                                <h4 class="mb-4 pb-3">Sign Up</h4>
                                                <div class="form-group">
                                                    <input type="text" name="name" class="form-style" placeholder="Your Full Name" id="logname" autocomplete="off">
                                                    <i class="input-icon uil uil-user"></i>
                                                </div>
                                                <div class="form-group mt-2">
                                                    <input type="email" name="email" class="form-style" placeholder="Your Email" id="logemail" autocomplete="off">
                                                    <i class="input-icon uil uil-at"></i>
                                                </div>
                                                <div class="form-group mt-2">
                                                    <input type="password" name="pass" class="form-style" placeholder="Your Password" id="logpass" autocomplete="off">
                                                    <i class="input-icon uil uil-lock-alt"></i>
                                                </div>
                                                <div>
                                                    <input type="submit" name="signup" class="btn mt-4">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
<?php
// include 'footer.php';
if (isset($_POST['login'])) {
    $reader_email = $_POST['reader_email'];
    $reader_password = $_POST['reader_pass'];
    $sql3 = "SELECT * FROM reader WHERE reader_email = '{$reader_email}' AND reader_password = '{$reader_password}'";
    $query3 = mysqli_query($config, $sql3);
    $data = mysqli_num_rows($query3);
    if ($data) {
        $result2 = mysqli_fetch_assoc($query3);
        $user_data = array($result2['reader_id'], $result2['reader_name'], $result2['reader_email']);
        $_SESSION['user_data'] = $user_data;
        header("location:index.php");
    } else {
        echo '<script>alert("Invalid email & password!.");</script>';
        // header("location:userLogin.php");
    }
}
?>
<?php
if (isset($_POST['signup'])) {
    $username = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['pass'];

    // Client-side validation
    if (empty($username) || empty($email) || empty($password)) {
        echo '<script>alert("All fields are required.");</script>';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo '<script>alert("Invalid email format.");</script>';
    } else {
        $sql = "SELECT * FROM reader WHERE reader_email = '$email'";
        $query = mysqli_query($config, $sql);
        $row = mysqli_num_rows($query);

        if ($row >= 1) {
            echo '<script>alert("Email already exists.");</script>';
        } else {
            $sql2 = "INSERT INTO reader (reader_name, reader_email, reader_password) VALUES('$username', '$email', '$password')";
            $query2 = mysqli_query($config, $sql2);

            if ($query2) {
                echo '<script>alert("User added successfully.");</script>';
                // header("location:userLogin.php");
            } else {
                echo '<script>alert("Error adding user.");</script>';
            }
        }
    }
}
?>