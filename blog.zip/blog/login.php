<?php 
include 'config.php';
// include 'header.php';
session_start();
ob_start();
if (isset($_SESSION['user_data'])) {
    header("location:http://localhost/blog/admin/index.php");
    }
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        #loginContainer {
            margin-top: 7%;
        }
    </style>
</head>
<body>
    <div class="container" id="loginContainer">
        <div class="row">
            <div class="col-xl-4 col-md-3 m-auto p-5 mt-5">
                <form action="" method="post" autocomplete="off">
                    <h4>Please Login</h4>
                    <div class="form-floating">
                        <input type="email" name="email"  class="form-control" id="floatingInput" placeholder="name@example.com" required>
                        <label for="floatingInput">Email address</label>
                    </div>
                    <div class="form-floating">
                        <input type="password" name="password" class="form-control" id="floatingPassword" placeholder="Password" required>
                        <label for="floatingPassword">Password</label>
                    </div>
                    <div class="mt-4 mb-3">
                        <input type="submit" name="login" class="btn btn-primary w-100 py-2" value="login">
                    </div>
                    <?php
                    if (isset($_SESSION['error'])) {
                        $error = $_SESSION['error'];
                        echo "<p class='bg-danger p-2 text-white'>".$error."</p>";
                        unset($_SESSION['error']);
                    }  
                    ?>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
<?php 
// include 'footer.php';
if(isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = sha1($_POST['password']);
    $sql = "SELECT * FROM user WHERE email = '{$email}' AND password = '{$password}'";
    $query = mysqli_query($config, $sql);
    $data = mysqli_num_rows($query);
    if ($data) {
        $result = mysqli_fetch_assoc($query);
        $user_data = array($result['user_id'], $result['username'], $result['role']);
        $_SESSION['user_data'] = $user_data;
        header("location:admin/index.php");
    }
    else {
        $_SESSION['error'] = "Invalid email/password";
        header("location:login.php");
    }
}
?>